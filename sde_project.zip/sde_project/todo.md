# Live Polling System - MVP Implementation Plan

## Core Features to Implement

### 1. Frontend Components (React)
- **src/pages/Index.tsx** - Landing page with Teacher/Student role selection
- **src/pages/TeacherDashboard.tsx** - Teacher interface for creating polls and viewing results
- **src/pages/StudentDashboard.tsx** - Student interface for answering polls and viewing results
- **src/components/PollCreator.tsx** - Form for teachers to create new polls
- **src/components/PollViewer.tsx** - Display active poll questions and options
- **src/components/ResultsChart.tsx** - Live results visualization
- **src/components/ParticipantsList.tsx** - List of connected students (for teacher view)

### 2. Backend Implementation (Express.js + Socket.io)
- **server/index.js** - Main server file with Express and Socket.io setup
- **server/pollManager.js** - Poll state management and business logic

## Key Features:
1. **Role Selection**: Choose between Teacher and Student
2. **Teacher Features**:
   - Create polls with question and multiple choice options
   - View live results
   - See connected students
   - Only allow new questions when previous is completed
3. **Student Features**:
   - Enter name on first visit
   - Answer active polls
   - View results after submission
   - 60-second timer per question
4. **Real-time Updates**: Socket.io for live polling and results
5. **UI Design**: Follow provided Figma design with purple color scheme

## File Structure:
- Frontend: React with shadcn-ui components
- Backend: Simple Express server with Socket.io
- State Management: React hooks + Socket.io events
- Styling: Tailwind CSS with custom purple theme

## Implementation Priority:
1. Basic UI structure and routing
2. Socket.io connection setup
3. Poll creation and management
4. Real-time voting functionality
5. Results visualization
6. Timer implementation
7. UI polish to match design