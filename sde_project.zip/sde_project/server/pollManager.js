class PollManager {
  constructor() {
    this.currentPoll = null;
    this.participants = new Set();
    this.answers = new Map();
    this.timer = null;
    this.timeLeft = 0;
  }

  createPoll(pollData) {
    this.currentPoll = {
      id: pollData.id,
      question: pollData.question,
      options: pollData.options,
      createdAt: new Date()
    };
    this.answers.clear();
    this.timeLeft = 60;
    return this.currentPoll;
  }

  getCurrentPoll() {
    return this.currentPoll;
  }

  addParticipant(name) {
    this.participants.add(name);
  }

  removeParticipant(name) {
    this.participants.delete(name);
    this.answers.delete(name);
  }

  getParticipants() {
    return Array.from(this.participants);
  }

  submitAnswer(pollId, studentName, answer) {
    if (!this.currentPoll || this.currentPoll.id !== pollId) {
      return false;
    }

    if (!this.participants.has(studentName)) {
      return false;
    }

    if (this.answers.has(studentName)) {
      return false; // Already answered
    }

    this.answers.set(studentName, answer);
    return true;
  }

  hasStudentAnswered(studentName) {
    return this.answers.has(studentName);
  }

  allStudentsAnswered() {
    return this.participants.size > 0 && this.answers.size === this.participants.size;
  }

  getResults() {
    if (!this.currentPoll) return null;

    const optionCounts = {};
    this.currentPoll.options.forEach(option => {
      optionCounts[option] = 0;
    });

    // Count votes
    for (let answer of this.answers.values()) {
      if (optionCounts.hasOwnProperty(answer)) {
        optionCounts[answer]++;
      }
    }

    const totalVotes = this.answers.size;
    const options = this.currentPoll.options.map(option => ({
      option,
      votes: optionCounts[option],
      percentage: totalVotes > 0 ? Math.round((optionCounts[option] / totalVotes) * 100) : 0
    }));

    return {
      question: this.currentPoll.question,
      options,
      totalVotes
    };
  }

  getPartialResults() {
    return this.getResults();
  }

  startTimer(onComplete, onTick) {
    this.clearTimer();
    
    this.timer = setInterval(() => {
      this.timeLeft--;
      onTick(this.timeLeft);
      
      if (this.timeLeft <= 0) {
        this.clearTimer();
        onComplete();
      }
    }, 1000);
  }

  clearTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  getTimeLeft() {
    return this.timeLeft;
  }

  endPoll() {
    this.clearTimer();
    const results = this.getResults();
    this.currentPoll = null;
    return results;
  }
}

module.exports = PollManager;