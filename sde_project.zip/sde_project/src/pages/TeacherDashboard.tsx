import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Plus, Users } from 'lucide-react';
import PollCreator from '@/components/PollCreator';
import PollViewer from '@/components/PollViewer';
import ResultsChart from '@/components/ResultsChart';
import ParticipantsList from '@/components/ParticipantsList';
import { useSocket } from '@/hooks/useSocket';

interface TeacherDashboardProps {
  onBack: () => void;
}

export default function TeacherDashboard({ onBack }: TeacherDashboardProps) {
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [activePoll, setActivePoll] = useState<any>(null);
  const [pollResults, setPollResults] = useState<any>(null);
  const [participants, setParticipants] = useState<string[]>([]);
  const [canCreateNewPoll, setCanCreateNewPoll] = useState(true);
  
  const socket = useSocket();

  useEffect(() => {
    if (!socket) return;

    socket.emit('join-as-teacher');

    socket.on('poll-created', (poll) => {
      setActivePoll(poll);
      setShowPollCreator(false);
      setCanCreateNewPoll(false);
    });

    socket.on('poll-results', (results) => {
      setPollResults(results);
    });

    socket.on('participants-updated', (participantsList) => {
      setParticipants(participantsList);
    });

    socket.on('poll-completed', () => {
      setCanCreateNewPoll(true);
    });

    return () => {
      socket.off('poll-created');
      socket.off('poll-results');
      socket.off('participants-updated');
      socket.off('poll-completed');
    };
  }, [socket]);

  const handleCreatePoll = (pollData: any) => {
    if (socket) {
      socket.emit('create-poll', pollData);
    }
  };

  const handleRemoveStudent = (studentName: string) => {
    if (socket) {
      socket.emit('remove-student', studentName);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h1>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Users className="w-5 h-5" />
            <span>{participants.length} students connected</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {!activePoll && canCreateNewPoll && (
              <Card>
                <CardHeader>
                  <CardTitle>Create New Poll</CardTitle>
                </CardHeader>
                <CardContent>
                  {showPollCreator ? (
                    <PollCreator 
                      onCreatePoll={handleCreatePoll}
                      onCancel={() => setShowPollCreator(false)}
                    />
                  ) : (
                    <Button 
                      onClick={() => setShowPollCreator(true)}
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Create New Poll
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {activePoll && (
              <PollViewer poll={activePoll} isTeacher={true} />
            )}

            {pollResults && (
              <ResultsChart results={pollResults} />
            )}

            {!activePoll && !canCreateNewPoll && (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-gray-600">Waiting for all students to answer the current question...</p>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <ParticipantsList 
              participants={participants}
              onRemoveStudent={handleRemoveStudent}
            />
          </div>
        </div>
      </div>
    </div>
  );
}